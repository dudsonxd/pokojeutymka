GALERIA — jak dodać zdjęcia z Booking.com
==========================================

Booking.com nie pozwala automatycznie pobierać zdjęć (blokada botów),
dlatego zdjęcia trzeba dodać ręcznie — to zajmuje kilka minut:

1. Wejdź na stronę pensjonatu na Booking.com i otwórz galerię zdjęć.
2. Dla każdego zdjęcia: kliknij prawym przyciskiem myszy -> "Zapisz obraz jako…"
3. Zapisz zdjęcia w TYM folderze (images/gallery/) i nazwij je kolejno
   numerami, zaczynając od 1:

   1.jpg
   2.jpg
   3.jpg
   ...
   160.jpg  (albo ile ich masz)

4. Strona (gallery.html) sama wykrywa, ile zdjęć jest w folderze —
   nie trzeba nic zmieniać w kodzie, wystarczy wgrać pliki.
   Jeśli chcesz zmienić maksymalną liczbę sprawdzanych zdjęć, zmień
   wartość TOTAL_PHOTOS na górze pliku js/gallery.js (domyślnie 160).

5. Format plików: .jpg (jeśli masz .png, zamień rozszerzenie w kodzie
   img.src w js/gallery.js, albo po prostu przekonwertuj pliki na .jpg).

Wskazówka: zdjęcia z Booking.com zwykle da się pobrać także w wyższej
rozdzielczości, edytując końcówkę adresu URL obrazka (np. zamieniając
"square60" lub "max300" na "max1024x768") przed zapisaniem.
